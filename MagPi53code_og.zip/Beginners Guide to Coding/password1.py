password = "qwerty"
attempt = input("Enter password: ")

if attempt == password:
    print("Welcome")
